/*
 * wangjian<wangjian@minigui.org>
 */

#ifndef __SIZE_480_272_H
#define __SIZE_480_272_H



#define SCREEN_W        480
#define SCREEN_H        272

/*the size of soft key board window*/
#define SKB_WIN_W       480
#define SKB_WIN_H       136  // +20

#define SKB_CLOSE_L     431
#define SKB_CLOSE_T     5
#define SKB_CLOSE_R     477
#define SKB_CLOSE_B     27

#define SKB_VW_L	23 
#define SKB_VW_T        5	//7
#define SKB_VW_R	406 
#define SKB_VW_B        26

#define SKB_VW_PU_L     23
#define SKB_VW_PU_T     3	//5
#define SKB_VW_PU_R     (23+23)
#define SKB_VW_PU_B     (5+23)

#define SKB_VW_PD_L	383 
#define SKB_VW_PD_T     3	//5
#define SKB_VW_PD_R     (383+23)
#define SKB_VW_PD_B     (5+23) 

#define SKB_SW_L        61
#define SKB_SW_T        25	//25
#define SKB_SW_R        378
#define SKB_SW_B        39	//39

#define SKB_KW_L        0  
#define SKB_KW_T        40 
#define SKB_KW_R        480
#define SKB_KW_B        136

/***** rectangle of the keys*****/
//add caona 
#define  ROW1_TY		41  
#define  ROW1_BY		62   
#define  ROW2_TY		65
#define  ROW2_BY		86
#define  ROW3_TY		89
#define  ROW3_BY		110
#define  ROW4_TY		113
#define  ROW4_BY		134

//For en keyboard....
//ROW_1
#define RECT_EN_KEY_1           {  2,  ROW1_TY,  46,  ROW1_BY}
#define RECT_EN_KEY_2           { 50,  ROW1_TY,  94,  ROW1_BY}
#define RECT_EN_KEY_3           { 98,  ROW1_TY, 142,  ROW1_BY}
#define RECT_EN_KEY_4           {146,  ROW1_TY, 190,  ROW1_BY}
#define RECT_EN_KEY_5           {194,  ROW1_TY, 238,  ROW1_BY}
#define RECT_EN_KEY_6           {242,  ROW1_TY, 286,  ROW1_BY}
#define RECT_EN_KEY_7           {290,  ROW1_TY, 334,  ROW1_BY}
#define RECT_EN_KEY_8           {338,  ROW1_TY, 382,  ROW1_BY}
#define RECT_EN_KEY_9           {386,  ROW1_TY, 430,  ROW1_BY}
#define RECT_EN_KEY_10          {434,  ROW1_TY, 478,  ROW1_BY}

#define RECT_EN_KEY_11          { 26,  ROW2_TY,  70,  ROW2_BY}
#define RECT_EN_KEY_12          { 74,  ROW2_TY, 118,  ROW2_BY}
#define RECT_EN_KEY_13          {122,  ROW2_TY, 166,  ROW2_BY}
#define RECT_EN_KEY_14          {170,  ROW2_TY, 214,  ROW2_BY}
#define RECT_EN_KEY_15          {218,  ROW2_TY, 262,  ROW2_BY}
#define RECT_EN_KEY_16          {266,  ROW2_TY, 310,  ROW2_BY}
#define RECT_EN_KEY_17          {314,  ROW2_TY, 358,  ROW2_BY}
#define RECT_EN_KEY_18          {362,  ROW2_TY, 406,  ROW2_BY}
#define RECT_EN_KEY_19          {410,  ROW2_TY, 454,  ROW2_BY}

#define RECT_EN_KEY_20          {  2,  ROW3_TY,  70, ROW3_BY}
#define RECT_EN_KEY_21          { 74,  ROW3_TY, 118, ROW3_BY}
#define RECT_EN_KEY_22          {122,  ROW3_TY, 166, ROW3_BY}
#define RECT_EN_KEY_23          {170,  ROW3_TY, 214, ROW3_BY}
#define RECT_EN_KEY_24          {218,  ROW3_TY, 262, ROW3_BY}
#define RECT_EN_KEY_25          {266,  ROW3_TY, 310, ROW3_BY}
#define RECT_EN_KEY_26          {314,  ROW3_TY, 358, ROW3_BY}
#define RECT_EN_KEY_27          {362,  ROW3_TY, 406, ROW3_BY}
#define RECT_EN_KEY_28          {410,  ROW3_TY, 478, ROW3_BY}

#define RECT_EN_KEY_29          {  2, ROW4_TY,  70, ROW4_BY}
#define RECT_EN_KEY_30          { 74, ROW4_TY, 108, ROW4_BY}
#define RECT_EN_KEY_31          {112, ROW4_TY, 368, ROW4_BY}
#define RECT_EN_KEY_32          {372, ROW4_TY, 478, ROW4_BY}

//For num keyboard....
#define RECT_NUM_KEY_1           {  2,  ROW1_TY,  46,  ROW1_BY}
#define RECT_NUM_KEY_2           { 50,  ROW1_TY,  94,  ROW1_BY}
#define RECT_NUM_KEY_3           { 98,  ROW1_TY, 142,  ROW1_BY}
#define RECT_NUM_KEY_4           {146,  ROW1_TY, 190,  ROW1_BY}
#define RECT_NUM_KEY_5           {194,  ROW1_TY, 238,  ROW1_BY}
#define RECT_NUM_KEY_6           {242,  ROW1_TY, 286,  ROW1_BY}
#define RECT_NUM_KEY_7           {290,  ROW1_TY, 334,  ROW1_BY}
#define RECT_NUM_KEY_8           {338,  ROW1_TY, 382,  ROW1_BY}
#define RECT_NUM_KEY_9           {386,  ROW1_TY, 430,  ROW1_BY}
#define RECT_NUM_KEY_10          {434,  ROW1_TY, 478,  ROW1_BY}

#define RECT_NUM_KEY_11          {  2,  ROW2_TY,  46,  ROW2_BY}
#define RECT_NUM_KEY_12          { 50,  ROW2_TY,  94,  ROW2_BY}
#define RECT_NUM_KEY_13          { 98,  ROW2_TY, 142,  ROW2_BY}
#define RECT_NUM_KEY_14          {146,  ROW2_TY, 190,  ROW2_BY}
#define RECT_NUM_KEY_15          {194,  ROW2_TY, 238,  ROW2_BY}
#define RECT_NUM_KEY_16          {242,  ROW2_TY, 286,  ROW2_BY}
#define RECT_NUM_KEY_17          {290,  ROW2_TY, 334,  ROW2_BY}
#define RECT_NUM_KEY_18          {338,  ROW2_TY, 382,  ROW2_BY}
#define RECT_NUM_KEY_19          {386,  ROW2_TY, 430,  ROW2_BY}
#define RECT_NUM_KEY_20          {434,  ROW2_TY, 478,  ROW2_BY}

#define RECT_NUM_KEY_21          {  2,  ROW3_TY,  65, ROW3_BY}
#define RECT_NUM_KEY_22          { 72,  ROW3_TY, 135, ROW3_BY}
#define RECT_NUM_KEY_23          {140,  ROW3_TY, 203, ROW3_BY}
#define RECT_NUM_KEY_24          {208,  ROW3_TY, 271, ROW3_BY}
#define RECT_NUM_KEY_25          {276,  ROW3_TY, 339, ROW3_BY}
#define RECT_NUM_KEY_26          {344,  ROW3_TY, 407, ROW3_BY}
#define RECT_NUM_KEY_27          {415,  ROW3_TY, 478, ROW3_BY}

#define RECT_NUM_KEY_28          {  2, ROW4_TY,  70, ROW4_BY}
#define RECT_NUM_KEY_29          { 74, ROW4_TY, 108, ROW4_BY}
#define RECT_NUM_KEY_30          {112, ROW4_TY, 368, ROW4_BY}
#define RECT_NUM_KEY_31          {372, ROW4_TY, 478, ROW4_BY}

#endif
